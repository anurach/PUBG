# PUBG Watchdog

Easily launch, close, or close and then re-launch PLAYERUNKNOWN'S Battlegrounds at the click of a button.

Also monitors PUBG's responsiveness, and if it is detected as frozen (such as loading in a match) it will close and re-launch PUBG automatically. If this detection doesn't work or you simply want to restart the game, there is a single big button you can press to do it anyway.
